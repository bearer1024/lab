package CO3090.assignment2;

public enum FileItemType {
    DIR,
    FILE,
    UNKNOWN
}
